import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @State private var showingAlert = false
    
    var body: some View {
        NavigationStack {
            Form {
                // Profile Section
                Section(header: Text("Profile")) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.largeTitle)
                            .foregroundStyle(.blue)
                        
                        TextField("Your Name", text: $appState.userName)
                            .textFieldStyle(.plain)
                    }
                }
                
                // Appearance Section
                Section(header: Text("Appearance")) {
                    Toggle(isOn: $appState.isDarkMode) {
                        Label("Dark Mode", systemImage: "moon.fill")
                    }
                }
                
                // App Info Section
                Section(header: Text("About")) {
                    HStack {
                        Label("Version", systemImage: "info.circle")
                        Spacer()
                        Text("1.0.0")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Label("Build", systemImage: "hammer")
                        Spacer()
                        Text("1")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Label("Platform", systemImage: "iphone")
                        Spacer()
                        Text("iOS")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Label("Launches", systemImage: "number")
                        Spacer()
                        Text("\(appState.launchCount)")
                            .foregroundStyle(.secondary)
                    }
                }
                
                // Actions Section
                Section(header: Text("Actions")) {
                    Button(role: .destructive) {
                        showingAlert = true
                    } label: {
                        Label("Reset All Settings", systemImage: "arrow.counterclockwise")
                    }
                }
                
                // Footer
                Section {
                    VStack(spacing: 8) {
                        Text("My iOS App Template")
                            .font(.headline)
                        Text("Built with ❤️ using SwiftUI")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                }
            }
            .navigationTitle("Settings")
            .alert("Reset Settings?", isPresented: $showingAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Reset", role: .destructive) {
                    appState.isDarkMode = false
                    appState.userName = ""
                    appState.launchCount = 0
                }
            } message: {
                Text("This will reset all your preferences. This cannot be undone.")
            }
        }
    }
}

#Preview {
    SettingsView()
        .environmentObject(AppState())
}
