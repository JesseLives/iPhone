# 🛠️ Complete Build Guide — From Source to Signed IPA

## Option A: Build with Codemagic (Free, No Mac Needed) ⭐ RECOMMENDED

### Step 1: Create a GitHub Account
1. Go to [github.com](https://github.com) → Sign up (free)

### Step 2: Upload Your Project
1. Create a new repository (e.g., "my-ios-app")
2. Upload all the files from this project folder
3. Make sure the folder structure matches:
   ```
   my-ios-app/
   ├── MyIOSApp.xcodeproj/
   ├── MyIOSApp/
   ├── codemagic.yaml
   └── .github/workflows/build.yml
   ```

### Step 3: Build on Codemagic
1. Go to [codemagic.io](https://codemagic.io) → **Start for free**
2. Click **Add application**
3. Select **GitHub** → authorize access
4. Select your `my-ios-app` repository
5. Choose **iOS App** workflow
6. The `codemagic.yaml` file will be auto-detected
7. Click **Start new build** → select **main** branch → **Start build**
8. Wait ~5-10 minutes for the build
9. Download `MyIOSApp.ipa` from the **Artifacts** section

### Step 4: Sign & Install with AltStore/Sideloadly
(See signing instructions below)

---

## Option B: Build with GitHub Actions (Free for Public Repos)

### Step 1: Create a PUBLIC GitHub repository
1. Go to [github.com](https://github.com) → **New repository**
2. Name it `my-ios-app`
3. Make it **PUBLIC** (required for free macOS runners)
4. Upload all project files

### Step 2: Trigger the Build
1. Go to your repository → **Actions** tab
2. Click **Build iOS IPA** workflow
3. Click **Run workflow** → **Run workflow**
4. Wait ~10-15 minutes

### Step 3: Download the IPA
1. When the build finishes (green ✓), click on the workflow run
2. Scroll down to **Artifacts** → click `MyIOSApp.ipa`
3. A ZIP file will download — extract it to get `MyIOSApp.ipa`

---

## Option C: Build on a Friend's Mac

If you can borrow a Mac:

```bash
# 1. Copy the project to the Mac
# 2. Open Terminal and navigate to the project
cd ~/path/to/MyIOSApp

# 3. Build without code signing
xcodebuild \
  -project MyIOSApp.xcodeproj \
  -scheme MyIOSApp \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO \
  clean archive

# 4. Create the .ipa
mkdir -p /tmp/Payload
cp -r build/Build/Products/Release-iphoneos/MyIOSApp.app /tmp/Payload/
cd /tmp && zip -r ~/Desktop/MyIOSApp.ipa Payload

echo "✅ IPA created at ~/Desktop/MyIOSApp.ipa"
```

---

## 🔐 Signing & Installing

### Method 1: AltStore (Easiest, Auto-Resigns)

**Setup (one-time):**
1. On your iPhone, open Safari → go to [altstore.io](https://altstore.io)
2. Download & install AltStore (follow on-screen instructions)
3. You may need to install AltServer on a PC first:
   - Download AltServer from altstore.io
   - Install on your Windows PC or Mac
   - Connect your iPhone via USB
   - Click AltServer in system tray → "Install AltStore" → select your device

**Install your IPA:**
1. Open **AltStore** on your iPhone
2. Tap the **+** button (top right)
3. Browse to your `MyIOSApp.ipa` file
4. AltStore will sign and install it automatically!
5. The app appears on your home screen

**Auto-refresh:**
- AltStore automatically re-signs apps in the background
- Just make sure AltServer is running on your PC/Mac occasionally
- Or use the AltStore Wi-Fi refresh feature

### Method 2: Sideloadly (Windows or Mac)

1. Download Sideloadly from [sideloadly.io](https://sideloadly.io)
2. Install on your Windows PC or Mac
3. Connect your iPhone via USB (or Wi-Fi)
4. Open Sideloadly
5. Drag `MyIOSApp.ipa` into the Sideloadly window
6. Enter your **Apple ID** email
7. Click **Start**
8. First time: Go to Settings → General → VPN & Device Management
9. Tap your Apple ID → **Trust**
10. The app is now on your home screen!

> ⚠️ Free signing lasts 7 days. Use Sideloadly to re-sign, or set up AltStore for auto-refresh.

### Method 3: TrollStore (Permanent, No Resigning!)

If your device supports TrollStore (check trollstore.app):
1. Install TrollStore on your device
2. Open TrollStore
3. Tap **+** → select your `MyIOSApp.ipa`
4. The app is permanently installed — no resigning needed!

---

## 🎯 Troubleshooting

### "Untrusted Developer" Error
1. Go to **Settings** → **General** → **VPN & Device Management**
2. Tap your Apple ID under "Developer App"
3. Tap **Trust**

### App Expires After 7 Days
This is normal with free signing. Solutions:
- Use **AltStore** (auto-refreshes)
- Re-sign weekly with **Sideloadly**
- Use **TrollStore** for permanent installation (if supported)

### Build Fails on Codemagic
- Make sure all files are uploaded correctly
- Check that `codemagic.yaml` is in the root of the repository
- Ensure the Xcode project structure matches

### Build Fails on GitHub Actions
- Make sure the repository is **public**
- Verify all source files are present
