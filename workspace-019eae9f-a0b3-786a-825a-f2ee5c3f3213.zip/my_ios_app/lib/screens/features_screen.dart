import 'package:flutter/material.dart';

class FeaturesScreen extends StatelessWidget {
  const FeaturesScreen({super.key});

  static const _features = [
    _Feature(
      icon: Icons.flutter_dash,
      title: 'Flutter',
      description: 'Cross-platform framework for beautiful, natively compiled apps.',
      color: Color(0xFF027DFD),
    ),
    _Feature(
      icon: Icons.dark_mode_rounded,
      title: 'Dark Mode',
      description: 'Automatic dark mode with Material 3 dynamic theming.',
      color: Color(0xFF6750A4),
    ),
    _Feature(
      icon: Icons.storage_rounded,
      title: 'Local Storage',
      description: 'Persistent settings using SharedPreferences.',
      color: Color(0xFF4CAF50),
    ),
    _Feature(
      icon: Icons.palette_rounded,
      title: 'Material 3',
      description: 'Modern Material Design 3 with dynamic color scheme.',
      color: Color(0xFFE91E63),
    ),
    _Feature(
      icon: Icons.navigation_rounded,
      title: 'Smooth Navigation',
      description: 'Bottom navigation bar with smooth tab transitions.',
      color: Color(0xFF2196F3),
    ),
    _Feature(
      icon: Icons.lock_rounded,
      title: 'Privacy First',
      description: 'No data collection. Everything stays on your device.',
      color: Color(0xFFF44336),
    ),
    _Feature(
      icon: Icons.cloud_build,
      title: 'Cloud Build',
      description: 'Build the IPA in the cloud — no Mac required!',
      color: Color(0xFFFF9800),
    ),
    _Feature(
      icon: Icons.phone_iphone,
      title: 'Native Feel',
      description: 'Cupertino-style elements mixed with Material for iOS feel.',
      color: Color(0xFF00BCD4),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Features'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        itemCount: _features.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final feature = _features[index];
          return _FeatureCard(feature: feature, theme: theme, colorScheme: colorScheme);
        },
      ),
    );
  }
}

class _FeatureCard extends StatefulWidget {
  final _Feature feature;
  final ThemeData theme;
  final ColorScheme colorScheme;

  const _FeatureCard({
    required this.feature,
    required this.theme,
    required this.colorScheme,
  });

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: widget.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        onTap: () => setState(() => _expanded = !_expanded),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: widget.feature.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  widget.feature.icon,
                  color: widget.feature.color,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.feature.title,
                      style: widget.theme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (!_expanded) ...[
                      const SizedBox(height: 2),
                      Text(
                        widget.feature.description,
                        style: widget.theme.textTheme.bodySmall?.copyWith(
                          color: widget.colorScheme.onSurfaceVariant,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    if (_expanded) ...[
                      const SizedBox(height: 4),
                      Text(
                        widget.feature.description,
                        style: widget.theme.textTheme.bodyMedium?.copyWith(
                          color: widget.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              Icon(
                _expanded ? Icons.expand_less : Icons.expand_more,
                color: widget.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Feature {
  final IconData icon;
  final String title;
  final String description;
  final Color color;

  const _Feature({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
  });
}
