import SwiftUI

struct FeaturesView: View {
    let features: [Feature] = [
        Feature(
            icon: "swift",
            title: "SwiftUI",
            description: "Built with modern SwiftUI framework for a native iOS experience.",
            color: .orange
        ),
        Feature(
            icon: "moon.stars.fill",
            title: "Dark Mode",
            description: "Automatic dark mode support with beautiful adaptive colors.",
            color: .indigo
        ),
        Feature(
            icon: "externaldrive.fill",
            title: "Local Storage",
            description: "Data is stored locally using SwiftUI's AppStorage.",
            color: .green
        ),
        Feature(
            icon: "paintbrush.fill",
            title: "Modern UI",
            description: "Clean, modern interface following Apple's design guidelines.",
            color: .pink
        ),
        Feature(
            icon: "square.stack.3d.up.fill",
            title: "Tab Navigation",
            description: "Easy tab-based navigation for seamless user experience.",
            color: .blue
        ),
        Feature(
            icon: "lock.fill",
            title: "Privacy First",
            description: "No data collection, no tracking. Your data stays on your device.",
            color: .red
        )
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    ForEach(features) { feature in
                        FeatureCard(feature: feature)
                    }
                }
                .padding()
            }
            .navigationTitle("Features")
        }
    }
}

struct Feature: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let description: String
    let color: Color
}

struct FeatureCard: View {
    let feature: Feature
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: feature.icon)
                .font(.title2)
                .foregroundStyle(feature.color)
                .frame(width: 48, height: 48)
                .background(feature.color.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(feature.title)
                    .font(.headline)
                Text(feature.description)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    FeaturesView()
}
