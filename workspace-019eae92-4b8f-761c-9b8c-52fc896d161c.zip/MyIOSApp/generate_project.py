#!/usr/bin/env python3
"""
Generate a complete Xcode project (.xcodeproj) for MyIOSApp.
Run this on macOS before opening in Xcode, or use it as reference.
"""

import os
import uuid
import json

def generate_uuid():
    """Generate a 24-character hex UUID for Xcode project."""
    return uuid.uuid4().hex[:24].upper()

# Generate consistent IDs (using deterministic values for reproducibility)
IDs = {
    "project": "PROJ001A1B2C3D4E5F6",  # Root project
    "mainGroup": "GRP000000000000001",
    "sourcesPBXGroup": "GRP000000000000002",
    "viewsPBXGroup": "GRP000000000000003",
    "assetsPBXGroup": "GRP000000000000004",
    "previewGroup": "GRP000000000000005",
    "frameworksGroup": "GRP000000000000006",
    "productsGroup": "GRP000000000000007",
    
    # Source files
    "appSwift": "SRC000000000000001",
    "appStateSwift": "SRC000000000000002",
    "contentViewSwift": "SRC000000000000003",
    "homeViewSwift": "SRC000000000000004",
    "featuresViewSwift": "SRC000000000000005",
    "settingsViewSwift": "SRC000000000000006",
    
    # Resources
    "infoPlist": "RSC000000000000001",
    "assetsCatalog": "RSC000000000000002",
    "previewAssets": "RSC000000000000003",
    
    # Products
    "appTarget": "PRD000000000000001",
    
    # Build phases
    "sourcesPhase": "BPH000000000000001",
    "resourcesPhase": "BPH000000000000002",
    "frameworksPhase": "BPH000000000000003",
    
    # Configurations
    "debugConfig": "CFG000000000000001",
    "releaseConfig": "CFG000000000000002",
    "configList": "CFGLIST00000000001",
    "targetConfigList": "CFGLIST00000000002",
    
    # Build file references
    "buildFile_app": "BFL000000000000001",
    "buildFile_appState": "BFL000000000000002",
    "buildFile_contentView": "BFL000000000000003",
    "buildFile_homeView": "BFL000000000000004",
    "buildFile_featuresView": "BFL000000000000005",
    "buildFile_settingsView": "BFL000000000000006",
    "buildFile_assets": "BFL000000000000007",
    
    # Container
    "projectContainer": "PXC000000000000001",
}

pbxproj = f'''// !$*UTF8*$!
{{
	archiveVersion = 1;
	classes = {{
	}};
	objectVersion = 56;
	objects = {{

/* Begin PBXBuildFile section */
		{IDs["buildFile_app"]} /* MyIOSAppApp.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["appSwift"]} /* MyIOSAppApp.swift */; }};
		{IDs["buildFile_appState"]} /* AppState.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["appStateSwift"]} /* AppState.swift */; }};
		{IDs["buildFile_contentView"]} /* ContentView.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["contentViewSwift"]} /* ContentView.swift */; }};
		{IDs["buildFile_homeView"]} /* HomeView.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["homeViewSwift"]} /* HomeView.swift */; }};
		{IDs["buildFile_featuresView"]} /* FeaturesView.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["featuresViewSwift"]} /* FeaturesView.swift */; }};
		{IDs["buildFile_settingsView"]} /* SettingsView.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {IDs["settingsViewSwift"]} /* SettingsView.swift */; }};
		{IDs["buildFile_assets"]} /* Assets.xcassets in Resources */ = {{isa = PBXBuildFile; fileRef = {IDs["assetsCatalog"]} /* Assets.xcassets */; }};
/* End PBXBuildFile section */

/* Begin PBXFileReference section */
		{IDs["appSwift"]} /* MyIOSAppApp.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = MyIOSAppApp.swift; sourceTree = "<group>"; }};
		{IDs["appStateSwift"]} /* AppState.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = AppState.swift; sourceTree = "<group>"; }};
		{IDs["contentViewSwift"]} /* ContentView.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = ContentView.swift; sourceTree = "<group>"; }};
		{IDs["homeViewSwift"]} /* HomeView.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = HomeView.swift; sourceTree = "<group>"; }};
		{IDs["featuresViewSwift"]} /* FeaturesView.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = FeaturesView.swift; sourceTree = "<group>"; }};
		{IDs["settingsViewSwift"]} /* SettingsView.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = SettingsView.swift; sourceTree = "<group>"; }};
		{IDs["assetsCatalog"]} /* Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = Assets.xcassets; sourceTree = "<group>"; }};
		{IDs["infoPlist"]} /* Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = "<group>"; }};
		{IDs["previewAssets"]} /* Preview Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = "Preview Content/Preview Assets.xcassets"; sourceTree = "<group>"; }};
		{IDs["appTarget"]} /* MyIOSApp.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = MyIOSApp.app; sourceTree = BUILT_PRODUCTS_DIR; }};
/* End PBXFileReference section */

/* Begin PBXFrameworksBuildPhase section */
		{IDs["frameworksPhase"]} /* Frameworks */ = {{
			isa = PBXFrameworksBuildPhase;
			buildActionMask = 2147483647;
			files = (
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXFrameworksBuildPhase section */

/* Begin PBXGroup section */
		{IDs["mainGroup"]} /* MyIOSApp */ = {{
			isa = PBXGroup;
			children = (
				{IDs["appTarget"]} /* Products */,
			);
			sourceTree = "<group>";
		}};
		{IDs["sourcesPBXGroup"]} /* MyIOSApp */ = {{
			isa = PBXGroup;
			children = (
				{IDs["viewsPBXGroup"]} /* Views */,
				{IDs["appSwift"]} /* MyIOSAppApp.swift */,
				{IDs["appStateSwift"]} /* AppState.swift */,
				{IDs["contentViewSwift"]} /* ContentView.swift */,
				{IDs["assetsPBXGroup"]} /* Assets */,
				{IDs["infoPlist"]} /* Info.plist */,
				{IDs["previewGroup"]} /* Preview Content */,
			);
			path = MyIOSApp;
			sourceTree = "<group>";
		}};
		{IDs["viewsPBXGroup"]} /* Views */ = {{
			isa = PBXGroup;
			children = (
				{IDs["homeViewSwift"]} /* HomeView.swift */,
				{IDs["featuresViewSwift"]} /* FeaturesView.swift */,
				{IDs["settingsViewSwift"]} /* SettingsView.swift */,
			);
			path = Views;
			sourceTree = "<group>";
		}};
		{IDs["assetsPBXGroup"]} /* Assets */ = {{
			isa = PBXGroup;
			children = (
				{IDs["assetsCatalog"]} /* Assets.xcassets */,
			);
			name = Assets;
			sourceTree = "<group>";
		}};
		{IDs["previewGroup"]} /* Preview Content */ = {{
			isa = PBXGroup;
			children = (
				{IDs["previewAssets"]} /* Preview Assets.xcassets */,
			);
			path = "Preview Content";
			sourceTree = "<group>";
		}};
		{IDs["productsGroup"]} /* Products */ = {{
			isa = PBXGroup;
			children = (
				{IDs["appTarget"]} /* MyIOSApp.app */,
			);
			name = Products;
			sourceTree = "<group>";
		}};
/* End PBXGroup section */

/* Begin PBXNativeTarget section */
		{IDs["projectContainer"]} /* MyIOSApp */ = {{
			isa = PBXNativeTarget;
			buildConfigurationList = {IDs["targetConfigList"]} /* Build configuration list for PBXNativeTarget "MyIOSApp" */;
			buildPhases = (
				{IDs["sourcesPhase"]} /* Sources */,
				{IDs["frameworksPhase"]} /* Frameworks */,
				{IDs["resourcesPhase"]} /* Resources */,
			);
			buildRules = (
			);
			dependencies = (
			);
			name = MyIOSApp;
			productName = MyIOSApp;
			productReference = {IDs["appTarget"]} /* MyIOSApp.app */;
			productType = "com.apple.product-type.application";
		}};
/* End PBXNativeTarget section */

/* Begin PBXProject section */
		{IDs["project"]} /* Project object */ = {{
			isa = PBXProject;
			attributes = {{
				BuildIndependentTargetsInParallel = 1;
				LastSwiftUpdateCheck = 1540;
				LastUpgradeCheck = 1540;
				TargetAttributes = {{
					{IDs["projectContainer"]} = {{
						CreatedOnToolsVersion = 15.4;
					}};
				}};
			}};
			buildConfigurationList = {IDs["configList"]} /* Build configuration list for PBXProject "MyIOSApp" */;
			compatibilityVersion = "Xcode 14.0";
			developmentRegion = en;
			hasScannedForEncodings = 0;
			knownRegions = (
				en,
				Base,
			);
			mainGroup = {IDs["mainGroup"]};
			productRefGroup = {IDs["productsGroup"]} /* Products */;
			projectDirPath = "";
			projectRoot = "";
			targets = (
				{IDs["projectContainer"]} /* MyIOSApp */,
			);
		}};
/* End PBXProject section */

/* Begin PBXResourcesBuildPhase section */
		{IDs["resourcesPhase"]} /* Resources */ = {{
			isa = PBXResourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
				{IDs["buildFile_assets"]} /* Assets.xcassets in Resources */,
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXResourcesBuildPhase section */

/* Begin PBXSourcesBuildPhase section */
		{IDs["sourcesPhase"]} /* Sources */ = {{
			isa = PBXSourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
				{IDs["buildFile_app"]} /* MyIOSAppApp.swift in Sources */,
				{IDs["buildFile_appState"]} /* AppState.swift in Sources */,
				{IDs["buildFile_contentView"]} /* ContentView.swift in Sources */,
				{IDs["buildFile_homeView"]} /* HomeView.swift in Sources */,
				{IDs["buildFile_featuresView"]} /* FeaturesView.swift in Sources */,
				{IDs["buildFile_settingsView"]} /* SettingsView.swift in Sources */,
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXSourcesBuildPhase section */

/* Begin XCBuildConfiguration section */
		{IDs["debugConfig"]} /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ALWAYS_SEARCH_USER_PATHS = NO;
				ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS = YES;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION = YES_AGGRESSIVE;
				CLANG_CXX_LANGUAGE_STANDARD = "gnu++20";
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				CLANG_ENABLE_OBJC_WEAK = YES;
				CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING = YES;
				CLANG_WARN_BOOL_CONVERSION = YES;
				CLANG_WARN_COMMA = YES;
				CLANG_WARN_CONSTANT_CONVERSION = YES;
				CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS = YES;
				CLANG_WARN_DIRECT_OBJC_ISA_USAGE = YES_ERROR;
				CLANG_WARN_DOCUMENTATION_COMMENTS = YES;
				CLANG_WARN_EMPTY_BODY = YES;
				CLANG_WARN_ENUM_CONVERSION = YES;
				CLANG_WARN_INFINITE_RECURSION = YES;
				CLANG_WARN_INT_CONVERSION = YES;
				CLANG_WARN_NON_LITERAL_NULL_CONVERSION = YES;
				CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF = YES;
				CLANG_WARN_OBJC_LITERAL_CONVERSION = YES;
				CLANG_WARN_OBJC_ROOT_CLASS = YES_ERROR;
				CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES;
				CLANG_WARN_RANGE_LOOP_ANALYSIS = YES;
				CLANG_WARN_STRICT_PROTOTYPES = YES;
				CLANG_WARN_SUSPICIOUS_MOVE = YES;
				CLANG_WARN_UNGUARDED_AVAILABILITY = YES_AGGRESSIVE;
				CLANG_WARN_UNREACHABLE_CODE = YES;
				CLANG_WARN__DUPLICATE_METHOD_MATCH = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = dwarf;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				ENABLE_TESTABILITY = YES;
				ENABLE_USER_SCRIPT_SANDBOXING = YES;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_DYNAMIC_NO_PIC = NO;
				GCC_NO_COMMON_BLOCKS = YES;
				GCC_OPTIMIZATION_LEVEL = 0;
				GCC_PREPROCESSOR_DEFINITIONS = (
					"DEBUG=1",
					"$(inherited)",
				);
				GCC_WARN_64_TO_32_BIT_CONVERSION = YES;
				GCC_WARN_ABOUT_RETURN_TYPE = YES_ERROR;
				GCC_WARN_UNDECLARED_SELECTOR = YES;
				GCC_WARN_UNINITIALIZED_AUTOS = YES_AGGRESSIVE;
				GCC_WARN_UNUSED_FUNCTION = YES;
				GCC_WARN_UNUSED_VARIABLE = YES;
				IPHONEOS_DEPLOYMENT_TARGET = 17.0;
				LOCALIZATION_PREFERS_STRING_KEYS = YES;
				MTL_ENABLE_DEBUG_INFO = INCLUDE_SOURCE;
				MTL_FAST_MATH = YES;
				ONLY_ACTIVE_ARCH = YES;
				SDKROOT = iphoneos;
				SWIFT_ACTIVE_COMPILATION_CONDITIONS = "$(inherited) DEBUG";
				SWIFT_OPTIMIZATION_LEVEL = "-Onone";
			}};
			name = Debug;
		}};
		{IDs["releaseConfig"]} /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ALWAYS_SEARCH_USER_PATHS = NO;
				ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS = YES;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION = YES_AGGRESSIVE;
				CLANG_CXX_LANGUAGE_STANDARD = "gnu++20";
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				CLANG_ENABLE_OBJC_WEAK = YES;
				CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING = YES;
				CLANG_WARN_BOOL_CONVERSION = YES;
				CLANG_WARN_COMMA = YES;
				CLANG_WARN_CONSTANT_CONVERSION = YES;
				CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS = YES;
				CLANG_WARN_DIRECT_OBJC_ISA_USAGE = YES_ERROR;
				CLANG_WARN_DOCUMENTATION_COMMENTS = YES;
				CLANG_WARN_EMPTY_BODY = YES;
				CLANG_WARN_ENUM_CONVERSION = YES;
				CLANG_WARN_INFINITE_RECURSION = YES;
				CLANG_WARN_INT_CONVERSION = YES;
				CLANG_WARN_NON_LITERAL_NULL_CONVERSION = YES;
				CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF = YES;
				CLANG_WARN_OBJC_LITERAL_CONVERSION = YES;
				CLANG_WARN_OBJC_ROOT_CLASS = YES_ERROR;
				CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES;
				CLANG_WARN_RANGE_LOOP_ANALYSIS = YES;
				CLANG_WARN_STRICT_PROTOTYPES = YES;
				CLANG_WARN_SUSPICIOUS_MOVE = YES;
				CLANG_WARN_UNGUARDED_AVAILABILITY = YES_AGGRESSIVE;
				CLANG_WARN_UNREACHABLE_CODE = YES;
				CLANG_WARN__DUPLICATE_METHOD_MATCH = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym";
				ENABLE_NS_ASSERTIONS = NO;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				ENABLE_USER_SCRIPT_SANDBOXING = YES;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_NO_COMMON_BLOCKS = YES;
				GCC_WARN_64_TO_32_BIT_CONVERSION = YES;
				GCC_WARN_ABOUT_RETURN_TYPE = YES_ERROR;
				GCC_WARN_UNDECLARED_SELECTOR = YES;
				GCC_WARN_UNINITIALIZED_AUTOS = YES_AGGRESSIVE;
				GCC_WARN_UNUSED_FUNCTION = YES;
				GCC_WARN_UNUSED_VARIABLE = YES;
				IPHONEOS_DEPLOYMENT_TARGET = 17.0;
				LOCALIZATION_PREFERS_STRING_KEYS = YES;
				MTL_FAST_MATH = YES;
				SDKROOT = iphoneos;
				SWIFT_COMPILATION_MODE = wholemodule;
				VALIDATE_PRODUCT = YES;
			}};
			name = Release;
		}};
		{IDs["projectContainer"]}_debug /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
				ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor;
				CODE_SIGN_STYLE = Automatic;
				CURRENT_PROJECT_VERSION = 1;
				DEVELOPMENT_TEAM = "";
				GENERATE_INFOPLIST_FILE = NO;
				INFOPLIST_FILE = MyIOSApp/Info.plist;
				INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES;
				INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES;
				INFOPLIST_KEY_UILaunchScreen_Generation = YES;
				INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad = "UIInterfaceOrientationPortrait UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight";
				INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone = "UIInterfaceOrientationPortrait";
				LD_RUNPATH_SEARCH_PATHS = (
					"$(inherited)",
					"@executable_path/Frameworks",
				);
				MARKETING_VERSION = 1.0;
				PRODUCT_BUNDLE_IDENTIFIER = com.example.MyIOSApp;
				PRODUCT_NAME = "$(TARGET_NAME)";
				SWIFT_EMIT_LOC_STRINGS = YES;
				SWIFT_VERSION = 5.0;
				TARGETED_DEVICE_FAMILY = "1,2";
			}};
			name = Debug;
		}};
		{IDs["projectContainer"]}_release /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
				ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor;
				CODE_SIGN_STYLE = Automatic;
				CURRENT_PROJECT_VERSION = 1;
				DEVELOPMENT_TEAM = "";
				GENERATE_INFOPLIST_FILE = NO;
				INFOPLIST_FILE = MyIOSApp/Info.plist;
				INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES;
				INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES;
				INFOPLIST_KEY_UILaunchScreen_Generation = YES;
				INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad = "UIInterfaceOrientationPortrait UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight";
				INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone = "UIInterfaceOrientationPortrait";
				LD_RUNPATH_SEARCH_PATHS = (
					"$(inherited)",
					"@executable_path/Frameworks",
				);
				MARKETING_VERSION = 1.0;
				PRODUCT_BUNDLE_IDENTIFIER = com.example.MyIOSApp;
				PRODUCT_NAME = "$(TARGET_NAME)";
				SWIFT_EMIT_LOC_STRINGS = YES;
				SWIFT_VERSION = 5.0;
				TARGETED_DEVICE_FAMILY = "1,2";
			}};
			name = Release;
		}};
/* End XCBuildConfiguration section */

/* Begin XCConfigurationList section */
		{IDs["configList"]} /* Build configuration list for PBXProject "MyIOSApp" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{IDs["debugConfig"]} /* Debug */,
				{IDs["releaseConfig"]} /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
		{IDs["targetConfigList"]} /* Build configuration list for PBXNativeTarget "MyIOSApp" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{IDs["projectContainer"]}_debug /* Debug */,
				{IDs["projectContainer"]}_release /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
/* End XCConfigurationList section */
	}};
	rootObject = {IDs["project"]} /* Project object */;
}}
'''

# Fix the mainGroup to include the source group
pbxproj = pbxproj.replace(
    f'''		{IDs["mainGroup"]} /* MyIOSApp */ = {{
			isa = PBXGroup;
			children = (
				{IDs["appTarget"]} /* Products */,
			);
			sourceTree = "<group>";
		}};''',
    f'''		{IDs["mainGroup"]} = {{
			isa = PBXGroup;
			children = (
				{IDs["sourcesPBXGroup"]} /* MyIOSApp */,
				{IDs["productsGroup"]} /* Products */,
			);
			sourceTree = "<group>";
		}};'''
)

# Write the project file
project_dir = "MyIOSApp.xcodeproj"
os.makedirs(project_dir, exist_ok=True)

with open(os.path.join(project_dir, "project.pbxproj"), "w") as f:
    f.write(pbxproj)

print("✅ Xcode project generated successfully!")
print(f"   → {project_dir}/project.pbxproj")
