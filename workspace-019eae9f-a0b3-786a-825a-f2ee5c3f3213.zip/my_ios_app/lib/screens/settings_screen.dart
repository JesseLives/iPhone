import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  final SharedPreferences prefs;

  const SettingsScreen({super.key, required this.prefs});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late bool _isDarkMode;
  late String _userName;
  late int _launchCount;

  @override
  void initState() {
    super.initState();
    _isDarkMode = widget.prefs.getBool('isDarkMode') ?? false;
    _userName = widget.prefs.getString('userName') ?? '';
    _launchCount = widget.prefs.getInt('launchCount') ?? 0;
  }

  void _resetSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset Settings?'),
        content: const Text(
          'This will reset all your preferences. This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              widget.prefs.remove('isDarkMode');
              widget.prefs.remove('userName');
              widget.prefs.remove('launchCount');
              setState(() {
                _isDarkMode = false;
                _userName = '';
                _launchCount = 0;
              });
              Navigator.pop(context);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: ListView(
        children: [
          const SizedBox(height: 8),

          // Profile Section
          _SectionHeader(title: 'Profile', theme: theme),
          _SettingsCard(
            colorScheme: colorScheme,
            theme: theme,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: colorScheme.primaryContainer,
                      child: Icon(
                        Icons.person,
                        size: 32,
                        color: colorScheme.primary,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          labelText: 'Your Name',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        controller: TextEditingController(text: _userName),
                        onChanged: (value) {
                          widget.prefs.setString('userName', value);
                          setState(() => _userName = value);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Appearance Section
          _SectionHeader(title: 'Appearance', theme: theme),
          _SettingsCard(
            colorScheme: colorScheme,
            theme: theme,
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.dark_mode_rounded),
                title: const Text('Dark Mode'),
                value: _isDarkMode,
                onChanged: (value) {
                  widget.prefs.setBool('isDarkMode', value);
                  setState(() => _isDarkMode = value);
                },
              ),
            ],
          ),

          const SizedBox(height: 20),

          // About Section
          _SectionHeader(title: 'About', theme: theme),
          _SettingsCard(
            colorScheme: colorScheme,
            theme: theme,
            children: [
              _SettingsTile(
                icon: Icons.info_outline_rounded,
                title: 'Version',
                trailing: '1.0.0',
                colorScheme: colorScheme,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Divider(height: 1),
              ),
              _SettingsTile(
                icon: Icons.build_rounded,
                title: 'Build',
                trailing: '1',
                colorScheme: colorScheme,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Divider(height: 1),
              ),
              _SettingsTile(
                icon: Icons.flutter_dash,
                title: 'Framework',
                trailing: 'Flutter',
                colorScheme: colorScheme,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Divider(height: 1),
              ),
              _SettingsTile(
                icon: Icons.touch_app_rounded,
                title: 'Launches',
                trailing: '$_launchCount',
                colorScheme: colorScheme,
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Actions Section
          _SectionHeader(title: 'Actions', theme: theme),
          _SettingsCard(
            colorScheme: colorScheme,
            theme: theme,
            children: [
              ListTile(
                leading: const Icon(Icons.restore_rounded, color: Colors.red),
                title: const Text(
                  'Reset All Settings',
                  style: TextStyle(color: Colors.red),
                ),
                onTap: _resetSettings,
              ),
            ],
          ),

          const SizedBox(height: 32),

          // Footer
          Center(
            child: Column(
              children: [
                Text(
                  'My iOS App Template',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Built with ❤️ using Flutter',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final ThemeData theme;

  const _SectionHeader({required this.title, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8),
      child: Text(
        title.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final ColorScheme colorScheme;
  final ThemeData theme;
  final List<Widget> children;

  const _SettingsCard({
    required this.colorScheme,
    required this.theme,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: children),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String trailing;
  final ColorScheme colorScheme;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.trailing,
    required this.colorScheme,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: Text(
        trailing,
        style: TextStyle(color: colorScheme.onSurfaceVariant),
      ),
    );
  }
}
