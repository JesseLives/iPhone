import SwiftUI

struct HomeView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    // Welcome Card
                    WelcomeCard(userName: appState.userName)
                    
                    // Quick Actions
                    QuickActionsGrid()
                    
                    // Recent Activity
                    RecentActivitySection()
                }
                .padding()
            }
            .navigationTitle("My App")
            .onAppear {
                if appState.launchCount == 0 {
                    appState.launchCount = 1
                } else {
                    appState.launchCount += 1
                }
            }
        }
    }
}

struct WelcomeCard: View {
    let userName: String
    
    var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        if hour < 12 { return "Good Morning" }
        else if hour < 17 { return "Good Afternoon" }
        else { return "Good Evening" }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(greeting)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(userName.isEmpty ? "Welcome!" : "\(userName)!")
                        .font(.title)
                        .bold()
                }
                Spacer()
                Image(systemName: "hand.wave.fill")
                    .font(.largeTitle)
                    .foregroundStyle(.yellow)
            }
            
            Text("This is your starter iOS app template. Customize it to make it your own!")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.blue.opacity(0.2), lineWidth: 1)
        )
    }
}

struct QuickActionsGrid: View {
    let actions: [(String, String, Color)] = [
        ("camera.fill", "Camera", .blue),
        ("photo.fill", "Photos", .green),
        ("doc.fill", "Files", .orange),
        ("map.fill", "Maps", .red)
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Actions")
                .font(.headline)
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 12) {
                ForEach(actions, id: \.0) { action in
                    QuickActionCard(icon: action.0, title: action.1, color: action.2)
                }
            }
        }
    }
}

struct QuickActionCard: View {
    let icon: String
    let title: String
    let color: Color
    @State private var isPressed = false
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(color)
                .frame(width: 50, height: 50)
                .background(color.opacity(0.15))
                .clipShape(Circle())
            
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.1)) {
                isPressed = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                withAnimation {
                    isPressed = false
                }
            }
        }
    }
}

struct RecentActivitySection: View {
    let activities: [(String, String, String)] = [
        ("app.fill", "App Launched", "Just now"),
        ("sparkles", "Template Ready", "Ready to customize"),
        ("checkmark.circle.fill", "All Systems Go", "Everything working")
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Status")
                .font(.headline)
            
            VStack(spacing: 0) {
                ForEach(Array(activities.enumerated()), id: \.offset) { index, activity in
                    HStack(spacing: 12) {
                        Image(systemName: activity.0)
                            .font(.body)
                            .foregroundStyle(.blue)
                            .frame(width: 32, height: 32)
                            .background(Color.blue.opacity(0.1))
                            .clipShape(Circle())
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(activity.1)
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Text(activity.2)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        
                        Spacer()
                    }
                    .padding(.vertical, 8)
                    
                    if index < activities.count - 1 {
                        Divider()
                    }
                }
            }
            .padding()
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }
}

#Preview {
    HomeView()
        .environmentObject(AppState())
}
