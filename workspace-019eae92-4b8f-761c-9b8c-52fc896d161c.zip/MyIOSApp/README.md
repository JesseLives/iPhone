# My iOS App Template

A beautiful, modern iOS app template built with **SwiftUI**. Ready to customize and sign with AltStore or Sideloadly!

## 📱 Features

- **SwiftUI** — Modern declarative UI framework
- **Dark Mode** — Full dark mode support
- **Tab Navigation** — Home, Features, and Settings tabs
- **Persistent Storage** — Settings saved using AppStorage
- **Clean Design** — Follows Apple's Human Interface Guidelines
- **Privacy First** — No data collection, everything stays on device

## 📁 Project Structure

```
MyIOSApp/
├── MyIOSApp.xcodeproj/       # Xcode project file
├── codemagic.yaml             # Cloud build config (Codemagic)
├── generate_project.py        # Project generator script
├── BUILD_GUIDE.md             # Detailed build instructions
└── MyIOSApp/
    ├── MyIOSAppApp.swift      # App entry point
    ├── AppState.swift         # Global app state
    ├── ContentView.swift      # Main content / tab view
    ├── Info.plist             # App configuration
    ├── Assets.xcassets/       # App icons & assets
    ├── Preview Content/       # SwiftUI previews
    └── Views/
        ├── HomeView.swift     # Home tab
        ├── FeaturesView.swift # Features tab
        └── SettingsView.swift # Settings tab
```

## 🚀 Quick Start (No Mac Required!)

### Method 1: Codemagic (Recommended — Free)

1. **Push to GitHub** — Upload this project to a GitHub repository
2. **Sign up** at [codemagic.io](https://codemagic.io) (free tier available)
3. **Connect** your GitHub repo
4. **Start build** — Codemagic will build the .ipa on a cloud Mac
5. **Download** the .ipa from the artifacts

### Method 2: GitHub Actions (Free for public repos)

1. Push to a **public** GitHub repository
2. The included workflow will automatically build the .ipa
3. Download from the Actions artifacts

### Method 3: If you have access to a Mac

```bash
# Open the project
open MyIOSApp.xcodeproj

# Or build from command line
xcodebuild -project MyIOSApp.xcodeproj \
  -scheme MyIOSApp \
  -configuration Release \
  -sdk iphoneos \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO \
  clean archive

# Create .ipa manually
mkdir -p /tmp/Payload
cp -r build/Build/Products/Release-iphoneos/MyIOSApp.app /tmp/Payload/
cd /tmp && zip -r ~/Desktop/MyIOSApp.ipa Payload
```

## 🔐 Signing with AltStore / Sideloadly

### Using AltStore
1. Download AltStore from [altstore.io](https://altstore.io)
2. Install AltStore on your iPhone
3. Open AltStore → tap **+** → select the `MyIOSApp.ipa` file
4. The app will be signed and installed!

### Using Sideloadly
1. Download Sideloadly from [sideloadly.io](https://sideloadly.io)
2. Connect your iPhone via USB
3. Open Sideloadly → drag the `MyIOSApp.ipa` into it
4. Enter your Apple ID → click **Start**
5. The app will be installed on your device!

> ⚠️ **Note**: Free Apple ID signing lasts **7 days**. Resign with AltStore to refresh.

## 🎨 Customization

- **App Name**: Edit `Info.plist` → `CFBundleDisplayName`
- **Bundle ID**: Edit `project.pbxproj` → `PRODUCT_BUNDLE_IDENTIFIER`
- **Colors**: Modify colors in each View file
- **Tabs**: Add/remove tabs in `ContentView.swift`
- **Features**: Add new views in the `Views/` folder

## 📋 Requirements

- iOS 17.0+ (change deployment target in project settings for older iOS)
- Xcode 15+ (for building on Mac)
