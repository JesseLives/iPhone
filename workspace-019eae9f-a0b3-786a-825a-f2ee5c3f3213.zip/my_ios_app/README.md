# My iOS App (Flutter) 📱

A beautiful, modern iOS app template built with **Flutter**. Ready to build in the cloud and sign with **AltStore** or **Sideloadly**!

## ✨ Features

| Feature | Description |
|---------|------------|
| 🐦 **Flutter** | Cross-platform framework — build from any OS |
| 🌙 **Dark Mode** | Full Material 3 dark/light theme support |
| 📱 **Material 3** | Modern design following latest guidelines |
| 🗂️ **Tab Navigation** | Home, Features, and Settings tabs |
| 💾 **Persistent Storage** | Settings saved with SharedPreferences |
| ☁️ **Cloud Build** | Build .ipa without a Mac (Codemagic/GitHub Actions) |
| 🔒 **Privacy First** | No data collection, everything on-device |

## 📁 Project Structure

```
my_ios_app/
├── lib/
│   ├── main.dart              # App entry point & theme
│   └── screens/
│       ├── home_screen.dart    # Home with greeting & quick actions
│       ├── features_screen.dart # Feature showcase (expandable)
│       └── settings_screen.dart # Name, dark mode, app info
├── ios/
│   └── Runner/                # iOS native configuration
│       ├── Info.plist
│       ├── AppDelegate.swift
│       └── Assets.xcassets/
├── codemagic.yaml             # Codemagic cloud build
├── .github/workflows/build.yml # GitHub Actions build
└── BUILD_GUIDE.md             # Detailed instructions
```

## 🚀 Quick Build (No Mac Needed!)

### Option 1: Codemagic ⭐ Recommended
1. Push to GitHub
2. Sign up at [codemagic.io](https://codemagic.io) (free)
3. Connect repo → Start build
4. Download `MyIOSApp.ipa`

### Option 2: GitHub Actions (free for public repos)
1. Push to a **public** GitHub repo
2. Go to **Actions** → **Build Flutter iOS IPA** → **Run workflow**
3. Download `.ipa` from artifacts

## 🔐 Sign & Install

- **AltStore**: Install from [altstore.io](https://altstore.io) → tap **+** → select .ipa
- **Sideloadly**: Download from [sideloadly.io](https://sideloadly.io) → drag .ipa → sign with Apple ID
- **TrollStore**: Permanent install (check compatibility at trollstore.app)

> ⚠️ Free Apple ID signing = 7 days. AltStore auto-refreshes.

## 🎨 Customization

- **App name**: Edit `ios/Runner/Info.plist` → `CFBundleDisplayName`
- **Bundle ID**: Change `com.example.myIosApp` everywhere
- **Theme colors**: Edit `colorSchemeSeed` in `lib/main.dart`
- **Add screens**: Create new files in `lib/screens/`

## 📋 Requirements

- iOS 12.0+ (change in `ios/Flutter/AppFrameworkInfo.plist`)
- Flutter 3.x (for building)
